//
//  mvViewController.swift
//  FansAreas
//
//  Created by admin on 2018/6/14.
//  Copyright © 2018年 dhy. All rights reserved.
//

import UIKit

class mvViewController: UIViewController {

    var mhPlayer: MHAVPlayerSDK?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = UIColor.white
        
        mhPlayer = MHAVPlayerSDK(frame: CGRect(x: 0, y: 30, width: view.frame.size.width, height: view.frame.size.width / 1.6))
        mhPlayer?.mhPlayerURL = "http://112.253.22.162/8/f/c/p/p/fcpppucacucrxwelrigynauhomqvgy/hc.yinyuetai.com/C441016103565A2775B70E0B1F411066.mp4?sc=9b9462ebdc18c0a2&br=795&vid=3136555&aid=215&area=ML&vst=0"
       // mhPlayer?.mhPlayerTitle = "第一部"
        mhPlayer?.MHAVPlayerSDKDelegate = self
        mhPlayer?.mhLastTime = 50
        mhPlayer?.mhAutoOrient = false
        view.addSubview(mhPlayer!)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}


extension mvViewController: MHAVPlayerSDKDelegate {
    
    func mhGoBack() {
        //            mhPlayer?.mhStopPlayer()
        //            self.dismiss(animated: true, completion: nil)
    }
    
    func mhNextPlayer() {
        mhPlayer?.mhPlayerURL = "http://baobab.wdjcdn.com/1455782903700jy.mp4"
        mhPlayer?.mhPlayerTitle = "第二部";
    }
    
}
