//
//  AddAreaTableViewController.swift
//  FansAreas
//
//  Created by admin on 2018/6/7.
//  Copyright © 2018年 dhy. All rights reserved.
//

import UIKit

class AddAreaTableViewController: UITableViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {

    @IBOutlet weak var head: UIImageView!

    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var username: UITextField!
    @IBOutlet weak var coverImageView: UIImageView!
    var dicArray = [Dictionary<String,String>]()
    var users = [user(name: "", password: "", range: "", image: "", money: "", myimage: "")]
    @IBAction func login(_ sender: Any) {
        let name = username.text!
        let pwd = password.text!
        users[0].name = name
        users[0].password = pwd
        for value in dicArray{
            if name == value["name"]{
                if pwd == value["pwd"]{
                    let vc = UIAlertController(title: "恭喜小主🐷🐷", message: "登录成功～可在主页查看个人信息哦！😊", preferredStyle: UIAlertControllerStyle.alert)
                    let btn = UIAlertAction(title: "确定", style: UIAlertActionStyle.default, handler:nil)
                    vc.addAction(btn)
                    self.present(vc, animated: true, completion: nil)
                    return
                }
                else{
                    let vc = UIAlertController(title: "信息", message: "输入密码有误", preferredStyle: UIAlertControllerStyle.alert)
                    let btn = UIAlertAction(title: "确定", style: UIAlertActionStyle.default, handler: nil)
                    vc.addAction(btn)
                    self.present(vc, animated: true, completion: nil)
                    return

                    username.text = ""
                    password.text = ""
                }
            }
            else{
                let vc = UIAlertController(title: "信息", message: "账号不存在", preferredStyle: UIAlertControllerStyle.alert)
                let btn = UIAlertAction(title: "确定", style: UIAlertActionStyle.default, handler: nil)
                vc.addAction(btn)
                self.present(vc, animated: true, completion: nil)
                return
                    
                    username.text = ""
                password.text = ""            }
        }

    }

    @IBAction func didregister(_ sender: Any) {
        let name = username.text!
        let pwd = password.text!
        var dict = Dictionary<String,String>()
        dict["name"] = name
        dict["pwd"] = pwd
        //判断用户名是否存在
        let vc = UIAlertController(title: "恭喜小主🐷", message: "注册成功，请前往登录😁", preferredStyle: UIAlertControllerStyle.alert)
        let btn = UIAlertAction(title: "确定", style: UIAlertActionStyle.default, handler:nil)
        vc.addAction(btn)
        self.present(vc, animated: true, completion: nil)
     dicArray.append(dict)
        
    
    }
    
    override func viewDidAppear(_ animated: Bool) {
        /*  从无到有
         UIView.animate(withDuration: 0.5) {
         self.ratingStackView.transform = CGAffineTransform.identity
         }
         */
        //震荡的效果
        UIView.animate(withDuration: 2.0, delay: 0, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.5, options: [], animations: {
            //self.ratingStackView.transform = CGAffineTransform.identity
            let endPos = CGAffineTransform(translationX: 0, y: 0)
            let endScale = CGAffineTransform.identity
            self.head.transform = endPos.concatenating(endScale)
        }, completion: nil)
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        let blurEffectView = UIVisualEffectView(effect: UIBlurEffect(style: .light))
        blurEffectView.frame = view.frame
        head.transform = CGAffineTransform(scaleX: 0, y: 0)//初始状态没有显示
        let startPos = CGAffineTransform(translationX: 0, y: 200)
        let startScale = CGAffineTransform(scaleX: 0, y: 0)
        head.transform = startScale.concatenating(startPos)
        

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }
   
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0{
            guard UIImagePickerController.isSourceTypeAvailable(.photoLibrary) else {
                print("相册不可用")
                return
            }
            let picker = UIImagePickerController()
            picker.allowsEditing = false
            picker.sourceType = .photoLibrary
            
            picker.delegate = self
            self.present(picker, animated: true, completion: nil)
        }
        tableView.deselectRow(at: indexPath, animated: true)
        
        
    }
    //取回相册中的照片
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        coverImageView.image=info[UIImagePickerControllerOriginalImage] as? UIImage
        coverImageView.contentMode = .scaleAspectFill
        coverImageView.clipsToBounds=true
        
        dismiss(animated: true, completion: nil)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if segue.identifier == "AreaTableViewController"{
            let dest = segue.destination as! AreaTableViewController
                       dest.users = self.users
            
        }
    }

    // MARK: - Table view data source
/*
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 0
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 0
    }
*/
    /*
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)

        // Configure the cell...

        return cell
    }
    */

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
