//
//  AreaTableViewController.swift
//  FansAreas
//
//  Created by admin on 2018/5/21.
//  Copyright © 2018年 dhy. All rights reserved.
//

import UIKit
import AVFoundation

class AreaTableViewController: UITableViewController {
    
    var users = [user(name: "", password: "", range: "", image: "", money: "", myimage: "")]
    var areas = [
        Area(name:"一 三 不 样 会 你 好 的 像 演 才 风 员 存 对", province: "像 风 一 样", part: "第一关", image: "xzq", isVisited: false) ,
        Area(name:"香 才 迷 样 可 无 好 迭 的 后 来 这 吗 几 十", province: "迷 迭 香 ", part: "第二关", image: "zjl", isVisited: false) ,
        Area(name:"三 明 市 园 的 后 来 这 吗 几 十 想 爱 我 你", province: "想 你 ", part: "第三关", image: "wyf", isVisited: false) ,
        Area(name:"西 爱 城 你 阳 光 说 楼 可 无 迭 好 的 后 来", province: "你 说 ", part: "第四关", image: "yyqx", isVisited: false) ,
        Area(name:"一 三 不 样 会 你 好 的 像 演 才 风 员 存 对", province: "像 风 一 样", part: "第五关", image: "xinzhuang", isVisited: false) ,
        Area(name:"香 才 迷 样 可 无 迭 好 的 后 来 这 吗 几 十", province: "迷 迭 香 ", part: "第六关", image: "qilihe", isVisited: false) ,
        Area(name:"三 明 市 园 的 后 来 这 吗 几 十 想 爱 我 你", province: "想 你 ", part: "第七关", image: "youxi", isVisited: false) ,
        Area(name:"西 爱 城 你 阳 光 说 楼 可 无 迭 好 的 后 来", province: "你 说 ", part: "第八关", image: "chengxi", isVisited: false) ,
        Area(name:"香 才 迷 样 可 无 迭 好 的 后 来 这 吗 几 十", province: "迷 迭 香 ", part: "第九关", image: "qilihe", isVisited: false) ,
        Area(name:"三 明 市 园 的 后 来 这 吗 几 十 想 爱 我 你", province: "想 你 ", part: "第十关", image: "youxi", isVisited: false) ,
        Area(name:"西 爱 城 你 阳 光 说 楼 可 无 迭 好 的 后 来", province: "你 说 ", part: "第十一关", image: "chengxi", isVisited: false) ,
    ]
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .plain, target: nil, action: nil)
        tableView.estimatedRowHeight = 190
        tableView.rowHeight = 190

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
     // MARK: - Table view delegate
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
     /*   let alertController = UIAlertController(title: "系统提示",
                                                message: "\(areas[indexPath.row])", preferredStyle: .actionSheet)
        let cancelAction = UIAlertAction(title: "取消", style: .cancel, handler: nil)
        let okAction = UIAlertAction(title: "我去过", style: .destructive, handler: {(UIAlertaction)
            in
            let cell = tableView.cellForRow(at: indexPath) as! CustomTableViewCell
            //cell?.accessoryType = .checkmark
            cell.aixin.isHidden = false
            self.visited[indexPath.row] = true
            
        })
        alertController.addAction(cancelAction)
        alertController.addAction(okAction)
        self.present(alertController, animated: true, completion: nil)
        print("你点击了第\(indexPath.row)行")
        tableView.deselectRow(at: indexPath, animated: true)*/
            }
    
   override func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let shareMenu = UITableViewRowAction(style: .default, title: "分享") { (UITableViewRowAction, IndexPath) in
        let actionSheet = UIAlertController(title: nil, message: "分享到", preferredStyle: .actionSheet)
        let wx = UIAlertAction(title: "微信", style: .default, handler: nil)
        let qq = UIAlertAction(title: "QQ", style: .default, handler: nil)
            let cancel = UIAlertAction(title: "取消", style: .cancel, handler: nil)
            actionSheet.addAction(wx)
            actionSheet.addAction(qq)
            actionSheet.addAction(cancel)
            self.present(actionSheet, animated: true, completion: nil)
            
            
    }
    let delMenu = UITableViewRowAction(style: .destructive, title: "删除") { (UITableViewRowAction, IndexPath) in
        self.areas.remove(at: indexPath.row)
        tableView.deleteRows(at: [indexPath], with: .fade)
    }
    shareMenu.backgroundColor = UIColor.orange
    return [delMenu,shareMenu]
    }
    
    // MARK: - Table view data source

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return areas.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        as! CustomTableViewCell
        cell.nameLabel.text = areas[indexPath.row].part
        cell.provinceLabel.text = " "
        
        cell.partLabel.text = (areas[indexPath.row].isVisited) ?"已通关":"未通关"
        cell.thumbImageView.image = UIImage(named: areas[indexPath.row].image)
//        cell.thumbImageView.layer.cornerRadius = cell.thumbImageView.frame.size.width/2
//        cell.thumbImageView.clipsToBounds = true
        if areas[indexPath.row].isVisited{
            //cell.accessoryType = .checkmark
            cell.aixin.isHidden = false
        }
        else{
        //cell.accessoryType = .none
             cell.aixin.isHidden = true
        }
        
               // Configure the cell...
        return cell
    }
    override var prefersStatusBarHidden: Bool{
    return true
    }
 
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

  
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            self.areas.remove(at: indexPath.row)
            
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }


    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if segue.identifier == "showAreaDetail"{
           let dest = segue.destination as! DetailTableViewController
            dest.area = areas[(tableView.indexPathForSelectedRow?.row)!]
            var destindex = tableView.indexPathForSelectedRow?.row
                     dest.areas = areas
            dest.curindex = destindex!

        }
        
        
    }
      @IBAction func close(segue:UIStoryboardSegue){
        let reviewVC = segue.source as! AddAreaTableViewController
        //if let users1 = reviewVC.users{
           // self.users = users1
        }
        
        

        
       // print("\(users)11111111")
    

    
//    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
//        
//        if(segue.identifier == "toBviewController"){
//            var bVc:BViewController = segue.destinationViewController as BViewController
//            bVc.tempString = textField.text
//            bVc.delegate = self
//        }
//    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        
        super.viewWillAppear(animated)
        
        setNavigationBarItem()
    }

    
    @IBAction func close(sugue:UIStoryboardSegue){
        
    }

}


