//
//  DetailTableViewController.swift
//  FansAreas
//
//  Created by admin on 2018/5/28.
//  Copyright © 2018年 dhy. All rights reserved.
//

import UIKit
import AVFoundation
class DetailTableViewController: UITableViewController {
    var area:Area!
    var curindex=0
    var areas = [
        Area(name:"", province: "", part: "", image: "", isVisited: false) ,
        Area(name:"", province: "", part: "", image: "", isVisited: false) ,
        Area(name:"", province: "", part: "", image: "", isVisited: false) ,
        Area(name:"", province: "", part: "", image: "", isVisited: false) ,
        Area(name:"", province: "", part: "", image: "", isVisited: false) ,
        Area(name:"", province: "", part: "", image: "", isVisited: false) ,

        
    ]
    @IBOutlet weak var bgimage: UIImageView!
    @IBOutlet weak var LargeImage: UIImageView!
    @IBOutlet weak var RatingBtn: UIButton!
    var myplayer = AVAudioPlayer()
    var mp3file = ""
    
    @IBOutlet weak var yesButton: UIButton!
    @IBOutlet weak var clearButton: UIButton!
    var mytimer = Timer()
var currentLevel = 0
    @IBOutlet weak var anwser4: UILabel!
    @IBOutlet weak var answer3: UILabel!
    @IBOutlet weak var answer2: UILabel!
    @IBOutlet weak var answer1: UILabel!
    
    @IBOutlet weak var pick1: UIButton!
    @IBOutlet weak var pick15: UIButton!
    @IBOutlet weak var pick14: UIButton!
    @IBOutlet weak var pick13: UIButton!
    @IBOutlet weak var pick12: UIButton!
  
    @IBOutlet weak var pick11: UIButton!
    @IBOutlet weak var pick10: UIButton!
    @IBOutlet weak var pick9: UIButton!
    @IBOutlet weak var pick8: UIButton!

    @IBOutlet weak var pick7: UIButton!
  
    @IBOutlet weak var pick6: UIButton!
    @IBOutlet weak var pick5: UIButton!
    @IBOutlet weak var pick4: UIButton!
    @IBOutlet weak var pick2: UIButton!
    @IBOutlet weak var pick3: UIButton!
    @IBAction func didpause(_ sender: Any) {
        myplayer.pause()
    }
   
    @IBAction func didplay(_ sender: Any) {
       
          myplayer.play()
    }
    @IBAction func sliderchange(_ sender: Any) {
        myplayer.currentTime = TimeInterval(myslider.value)*myplayer.duration

    }
    func refreshProgress(){
        myslider.value = Float(myplayer.currentTime / myplayer.duration)
    }
    func musicchange(curindex1:Int){
        mp3file = "/Users/admin/Desktop/music/" + "\(areas[curindex1].province).mp3"
        print(areas[curindex1].province)
        let url = NSURL(fileURLWithPath: mp3file)
        do{
            
            try myplayer = AVAudioPlayer(contentsOf: url as URL)
            myplayer.prepareToPlay()
            myplayer.play()
            //进度条更新
            mytimer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(DetailTableViewController.refreshProgress), userInfo: nil, repeats: true)
        }catch{
            print("音乐播放失败")}

    }
    @IBOutlet weak var myslider: UISlider!
    override func viewDidLoad() {
        bgimage.image = UIImage(named: area.image)
        let blurEffectView = UIVisualEffectView(effect: UIBlurEffect(style: .light))
        blurEffectView.frame = view.frame
        
        bgimage.addSubview(blurEffectView)
        super.viewDidLoad()
        musicchange(curindex1:curindex)
                title = area.part
//        LargeImage.image = UIImage(named: area.image)?.toCircle()
//        //let image = UIImage(named: "image1")?.toCircle()
//        //创建imageView
//        let imageView = UIImageView(image: LargeImage.image)
//        imageView.frame = CGRect(x:50, y:30, width:210, height:210)
//        
//        // 1.创建动画
//        let rotationAnim = CABasicAnimation(keyPath: "transform.rotation.z")
//        // 2.设置动画的属性
//        rotationAnim.fromValue = 0
//        rotationAnim.toValue = M_PI * 2
//        rotationAnim.repeatCount = MAXFLOAT
//        rotationAnim.duration = 5
//        // 这个属性很重要 如果不设置当页面运行到后台再次进入该页面的时候 动画会停止
//        rotationAnim.isRemovedOnCompletion = false
//        // 3.将动画添加到layer中
//        imageView.layer.add(rotationAnim, forKey: nil)
//        self.view.addSubview(imageView)
//        
//        tableView.backgroundColor = UIColor(white:0.8,alpha:1.0)
//        tableView.separatorColor = UIColor.blue
//        tableView.tableFooterView = UIView(frame: CGRect.zero)
//        
//        tableView.estimatedRowHeight = 66
//        tableView.rowHeight = UITableViewAutomaticDimension
//        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        
       // print("currentLevel:\(currentLevel)==答案：\(tis[currentLevel-1].daan)")
        setguessTitle(curindex: curindex)
        
        yesButton.transform = CGAffineTransform(scaleX: 0, y: 0)//初始状态没有显示
        clearButton.transform = CGAffineTransform(scaleX: 0, y: 0)//初始状态没有显示
        let startPos = CGAffineTransform(translationX: 0, y: 500)
        let startScale = CGAffineTransform(scaleX: 0, y: 0)
        yesButton.transform = startScale.concatenating(startPos)
          clearButton.transform = startScale.concatenating(startPos)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        /*  从无到有
         UIView.animate(withDuration: 0.5) {
         self.ratingStackView.transform = CGAffineTransform.identity
         }
         */
        //震荡的效果
        UIView.animate(withDuration: 1.3, delay: 0, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.5, options: [], animations: {
            //self.ratingStackView.transform = CGAffineTransform.identity
            let endPos = CGAffineTransform(translationX: 0, y: 0)
            let endScale = CGAffineTransform.identity
            self.yesButton.transform = endPos.concatenating(endScale)
             self.clearButton.transform = endPos.concatenating(endScale)
        }, completion: nil)
    }
    

    
    func setguessTitle(curindex:Int){

        switch areas[curindex].province.characters.count {
        case 4:
            answer3.isHidden = true
            anwser4.isHidden = true
            
        case 6:
            anwser4.isHidden = true
            
        default:
            print("error")
        }
        bgimage.image = UIImage(named: areas[curindex].image)
        

       musicchange(curindex1:curindex)

        answer1.text = " "
        answer2.text = " "
        answer3.text = " "
        anwser4.text = " "
        LargeImage.image = UIImage(named: areas[curindex].image)?.toCircle()
        //let image = UIImage(named: "image1")?.toCircle()
        //创建imageView
        let imageView = UIImageView(image: LargeImage.image)
        imageView.frame = CGRect(x:50, y:30, width:210, height:210)
        
        // 1.创建动画
        let rotationAnim = CABasicAnimation(keyPath: "transform.rotation.z")
        // 2.设置动画的属性
        rotationAnim.fromValue = 0
        rotationAnim.toValue = M_PI * 2
        rotationAnim.repeatCount = MAXFLOAT
        rotationAnim.duration = 5
        // 这个属性很重要 如果不设置当页面运行到后台再次进入该页面的时候 动画会停止
        rotationAnim.isRemovedOnCompletion = false
        // 3.将动画添加到layer中
        imageView.layer.add(rotationAnim, forKey: nil)
        self.view.addSubview(imageView)
        
        tableView.backgroundColor = UIColor(white:0.8,alpha:1.0)
        tableView.separatorColor = UIColor.blue
        tableView.tableFooterView = UIView(frame: CGRect.zero)
        
        tableView.estimatedRowHeight = 66
        tableView.rowHeight = UITableViewAutomaticDimension
        

        let splitedArray = areas[curindex].name.characters.split{$0 == " "}.map(String.init)
        
        pick1.setTitle("\(splitedArray[0])", for: .normal)
        pick2.setTitle("\(splitedArray[1])", for: .normal)
        pick3.setTitle("\(splitedArray[2])", for: .normal)
        pick4.setTitle("\(splitedArray[3])", for: .normal)
        pick5.setTitle("\(splitedArray[4])", for: .normal)
        pick6.setTitle("\(splitedArray[5])", for: .normal)
        pick7.setTitle("\(splitedArray[6])", for: .normal)
        pick8.setTitle("\(splitedArray[7])", for: .normal)
        pick9.setTitle("\(splitedArray[8])", for: .normal)
        pick10.setTitle("\(splitedArray[9])", for: .normal)
        pick11.setTitle("\(splitedArray[10])", for: .normal)
        pick12.setTitle("\(splitedArray[11])", for: .normal)
        pick13.setTitle("\(splitedArray[12])", for: .normal)
        pick14.setTitle("\(splitedArray[13])", for: .normal)
        pick15.setTitle("\(splitedArray[14])", for: .normal)

    }
       override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

  
    @IBAction func pickwhich(_ sender: UIButton) {
        
        var mm = " "
        let myString = (sender.currentTitle)!
        if answer1.text == " "{answer1.text = "\(myString)"}
        else if answer2.text == " "{answer2.text = "\(myString)"}
        else if answer3.text == " "{answer3.text = "\(myString)"}
        else if anwser4.text == " "{anwser4.text = "\(myString)"
            
            mm = "\(answer1.text!)\(answer2.text!)\(answer3.text!)\(anwser4.text!)"
            
        }
    }
    @IBAction func nextSection(_ sender: Any) {
        if  self.currentLevel >= 2{
            let alert = UIAlertController(title: "恭喜小主~", message: "您通关啦！*(#^.^#)", preferredStyle: UIAlertControllerStyle.alert)
            let actionYes = UIAlertAction(title: "确定", style: UIAlertActionStyle.default, handler: nil)
            alert.addAction(actionYes)
            self.present(alert,animated: true,completion: nil)
        }
        var mm = ""
        switch areas[curindex].province.characters.count {
        case 4:
            mm = "\(answer1.text!)  \(answer2.text!) "
            
        case 6:
            mm = "\(answer1.text!) \(answer2.text!) \(answer3.text!)"+" "
            print("111\(mm)")
        default:
           mm = "\(answer1.text!) \(answer2.text!) \(answer3.text!) \(anwser4.text!)"
        }

       
        print(mm)
        if mm == areas[curindex].province{
            area.isVisited=true
            currentLevel = currentLevel + 1
            curindex = curindex + 1
            let alert = UIAlertController(title: "恭喜小主~", message: "答案正确！可进入下一关*(#^.^#)", preferredStyle: UIAlertControllerStyle.alert)
            let actionYes = UIAlertAction(title: "确定", style: UIAlertActionStyle.default, handler: {
                action in
                //self.currentLevel += 1
                // allLevels[self.currentLevel] = 1
                //writeAllLevels()
                
                //self.area = self.areas[self.curindex]
                self.setguessTitle(curindex:self.curindex)
                print(self.curindex)
                })
            alert.addAction(actionYes)
            self.present(alert,animated: true,completion: nil)
            
        }
        else{
            let alert = UIAlertController(title: "抱歉小主~", message: "回答错误，请继续闯关*(#^.^#)", preferredStyle: UIAlertControllerStyle.alert)
            let actionYes = UIAlertAction(title: "确定", style: UIAlertActionStyle.default, handler: {
                action in
                //self.currentLevel += 1
                // allLevels[self.currentLevel] = 1
                //writeAllLevels()
                
                //area = area + 1
                self.anwser4.text = ""
                self.answer1.text = ""
                self.answer2.text = ""
                self.answer3.text = ""

                print(self.curindex)
            })
            alert.addAction(actionYes)
            self.present(alert,animated: true,completion: nil)
        }
        
    }
 
        @IBAction func clear(_ sender: Any) {
        anwser4.text = ""
        answer1.text = ""
        answer2.text = ""
        answer3.text = ""
        
    }
    
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 4
    }

   
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DetailCell", for: indexPath) as! DetailTableViewCell
        switch indexPath.row {
        case 0:
            cell.fieldLabel.text = "地名"
            cell.valueLabel.text = area.name
        case 1:
            cell.fieldLabel.text = "省"
            cell.valueLabel.text = area.province
        case 2:
            cell.fieldLabel.text = "地区"
            cell.valueLabel.text = area.part
        case 3:
            cell.fieldLabel.text = "是否去过"
            cell.valueLabel.text = area.isVisited ?"去过": "没去过"
        default:
            break
        }
        // Configure the cell...
        cell.backgroundColor = UIColor.clear
        
        return cell
    }

    
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if segue.identifier == "showReview"{
            let dest = segue.destination as! ReviewViewController
            dest.area = self.area
        }
        if segue.identifier == "showmap" {
            let dest = segue.destination as! MapViewController
            dest.area = self.area
        }
    }
    

    @IBAction func close(segue:UIStoryboardSegue){
        let reviewVC = segue.source as! ReviewViewController
        if let rating = reviewVC.rating{
            self.area.rating = rating
            self.RatingBtn.setImage(UIImage(named:rating), for: .normal)
        }
    }
}

extension UIImage {
    //生成圆形图片
    func toCircle() -> UIImage {
        //取最短边长
        let shotest = min(self.size.width, self.size.height)
        //输出尺寸
        let outputRect = CGRect(x: 0, y: 0, width: shotest, height: shotest)
        //开始图片处理上下文（由于输出的图不会进行缩放，所以缩放因子等于屏幕的scale即可）
        UIGraphicsBeginImageContextWithOptions(outputRect.size, false, 0)
        let context = UIGraphicsGetCurrentContext()!
        //添加圆形裁剪区域
        context.addEllipse(in: outputRect)
        context.clip()
        //绘制图片
        self.draw(in: CGRect(x: (shotest-self.size.width)/2,
                             y: (shotest-self.size.height)/2,
                             width: self.size.width,
                             height: self.size.height))
        //获得处理后的图片
        let maskedImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        return maskedImage
    }
}
