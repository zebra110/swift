//
//  ReviewViewController.swift
//  FansAreas
//
//  Created by admin on 2018/6/4.
//  Copyright © 2018年 dhy. All rights reserved.
//

import UIKit

class ReviewViewController: UIViewController {
    var area:Area!
    @IBOutlet weak var bgImageView: UIImageView!
    @IBOutlet weak var ratingStackView: UIStackView!
    var rating:String?
    @IBAction func ratingButtonClicked(_ sender: UIButton) {
        switch sender.tag {
        case 0:
            rating = "dislike"
        case 1:
            rating = "good"
        case 2:
            rating = "great"
        default:
            break
        }
        //返回转场
        performSegue(withIdentifier: "unwindToDetailView", sender: sender)
    }
    
    @IBOutlet weak var prompt: UILabel!

   
    override func viewDidLoad() {
        super.viewDidLoad()
        let splitedArray = area.province.characters.split{$0 == " "}.map(String.init)
         prompt.text = splitedArray[1]
        bgImageView.image = UIImage(named: area.image)
        let blurEffectView = UIVisualEffectView(effect: UIBlurEffect(style: .light))
        blurEffectView.frame = view.frame
        bgImageView.addSubview(blurEffectView)
        prompt.transform = CGAffineTransform(scaleX: 0, y: 0)//初始状态没有显示
        let startPos = CGAffineTransform(translationX: 0, y: 500)
        let startScale = CGAffineTransform(scaleX: 0, y: 0)
        prompt.transform = startScale.concatenating(startPos)

        // Do any additional setup after loading the view.
    }
    override func viewDidAppear(_ animated: Bool) {
        /*  从无到有
        UIView.animate(withDuration: 0.5) {
            self.ratingStackView.transform = CGAffineTransform.identity
        }
        */
        //震荡的效果
        UIView.animate(withDuration: 1.3, delay: 0, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.5, options: [], animations: {
            //self.ratingStackView.transform = CGAffineTransform.identity
            let endPos = CGAffineTransform(translationX: 0, y: 0)
            let endScale = CGAffineTransform.identity
            self.prompt.transform = endPos.concatenating(endScale)
        }, completion: nil)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
