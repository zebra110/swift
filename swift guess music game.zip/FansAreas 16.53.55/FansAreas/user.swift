//
//  user.swift
//  FansAreas
//
//  Created by admin on 2018/6/14.
//  Copyright © 2018年 dhy. All rights reserved.
//


import Foundation

struct user{
    var name:String
    var password:String
    var range:String
    var money:String
    var myimage:String
   
    init(name: String, password: String, range: String, image: String, money: String, myimage: String){
        self.name = name
        self.password = password
        self.range = range
        self.money = money
        self.myimage = myimage
    }
}
