//
//  Area.swift
//  FansAreas
//
//  Created by admin on 2018/5/28.
//  Copyright © 2018年 dhy. All rights reserved.
//

import Foundation

struct Area{
    var name:String
    var province:String
    var part:String
    var image:String
    var isVisited:Bool
    var rating = ""
    init(name: String, province: String, part: String, image: String, isVisited: Bool){
        self.name = name
        self.province = province
        self.image = image
        self.isVisited = isVisited
        self.part = part
    }
}
